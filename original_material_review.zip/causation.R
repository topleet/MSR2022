pdf("generated/causation.pdf", width = 5, height = 4)
par(mfrow = c(1, 1), mar = c(4, 4, 1, 1))

set.seed(1)
result.lr <- NULL
result.ao <- NULL

for (beta in seq(-1, 1, length.out = 30)) {
  N <- 1000
  alpha <- -3.0

  X <- rnorm(N)

  # Producing two alternative outcomes.
  prob_alt1 <- 1 / (1 + exp(-(alpha + beta * X)))
  prob_alt2 <- 1 / (1 + exp(-(alpha + beta * (X + 1))))
  # Corresponding alternative defects.
  Y_alt1 <- rbinom(N, size = 1, prob = prob_alt1)
  Y_alt2 <- rbinom(N, size = 1, prob = prob_alt2)

  model <- glm(Y_alt1 ~ X, family = binomial())

  result.ao <- c(result.ao, mean(Y_alt2 - Y_alt1))
  result.lr <- c(result.lr, coef(model)["X"])
}

plot(result.ao, result.lr, xlab = "Difference Potential Outcomes", ylab = "Inferred Beta by Logistic regression", pch = 16)

dev.off()

# set.seed(1)
#
# data <- read.csv("data/metrics_elasticsearch.csv")
#
# X <- log(data$linesChanged + 1)
#
# N <- length(X)
# # Unobserved variable
# alpha <- -3.0
# beta <- 0.4
#
# prob_alt1 <- 1 / (1 + exp(-(alpha + beta1 * X1)))
# prob_alt2 <- 1 / (1 + exp(-(alpha + beta1 * (X1 - 1))))
#
# # We can just observe Y1.
# Y1_alt1 <- rbinom(N, size = 1, prob = prob_alt1)
# Y2_alt2 <- rbinom(N, size = 1, prob = prob_alt2)
#
# print(mean(Y1) / mean(Y2))
#
# model <- glm(Y1 ~ X1, family = binomial())
#
# coef(model)


# set.seed(1)
#
# N <- 30069
#
# X2 <- rnorm(N)
# X1 <- rnorm(N, mean = X2)
#
# # Unobserved variable
# alpha <- -3.0
# beta1 <- 0.4
# beta2 <- -1
#
# prob1 <- 1 / (1 + exp(-(alpha + beta1 * X1 + beta2 * X2)))
# prob2 <- 1 / (1 + exp(-(alpha + beta1 * (X1 - 1) + beta2 * X2)))
#
# # We can just observe Y1.
# Y1 <- rbinom(N, size = 1, prob = prob1)
# Y2 <- rbinom(N, size = 1, prob = prob2)
#
# print(mean(Y1) / mean(Y2))
#
# model <- glm(Y1 ~ X1, family = binomial())
# #
# # coef(model)
