library(lsa) # Needed for cosine similarity.
fails <- 0
for (i in 1:100) {
  N <- 8000
  alpha <- -3.0
  beta <- 0.4
  X <- NULL
  E <- NULL
  for (n in 1:N) {
    nTerms <- 200
    # Generate two random term vectors.
    back <- rpois(n = nTerms, lambda = 5.0)
    file <- rpois(n = nTerms, lambda = 0.1)
    # Compute the similarity defining experience.
    E <- c(E, cosine(back, file))
    # Size of the file.
    X <- c(X, log(sum(file) + 1))
  }

  prob <- 1 / (1 + exp(-(alpha + beta * X)))

  # Substituted observed variable Y.
  Y <- rbinom(N, size = 1, prob = prob)

  fails <- sum(fails, wilcox.test(E ~ Y)$p.value < 0.05)
}

pdf("generated/control.pdf", width = 5, height = 4)
par(mfrow = c(1, 1), mar = c(4, 4, 1, 1))
plot(X[1:400], E[1:400], pch = 16, xlab = "File Size (X)", ylab = "Experience (E)")

dev.off()