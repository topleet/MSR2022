data <- read.csv("data/metrics_elasticsearch.csv")

X <- log(data$linesChanged + 1)
Y <- as.integer(data$buggy == "true")

results <- NULL

for (alpha in seq(-10, 10, length.out = 30)) {
  for (beta in seq(-1, 1, length.out = 30)) {
    # Observed variable N and X.
    N <- length(X) # Number of commits (cf. original data set).
    X <- X # N random values (normal dist.).

    # Unobserved variable
    prob <- 1 / (1 + exp(-(alpha + beta * X)))

    # Observed variable Y.
    Y <- rbinom(N, size = 1, prob = prob)

    model <- glm(Y ~ X, family = binomial())

    ndefects <- sum(Y)

    results <- rbind(results, c(coef(model), alpha, beta, ndefects))
  }
}
error <- pmin(abs(results[, 2] - results[, 4]), 1)
pdf("generated/nutshell_parameters.pdf", width = 6, height = 3)
par(mfrow = c(1, 2), mar = c(4, 4, 2, 1))
plot(results[, 3], results[, 4], col = rgb(1, 0, 0, error), pch = 16,
     xlab = "alpha", ylab = "beta", main = "")

plot(log(results[, 5]),error, xlab = "number of defects (log)")

dev.off()

# pdf("generated/nutshell.pdf", width = 6, height = 3)
# par(mfrow = c(1, 2), mar = c(2, 4, 2, 1))
# hist(results[, 1], breaks = 20, main = "Inferred Intercepts", xlab = "")
# hist(results[, 2], breaks = 20, main = "Inferred Slopes", xlab = "")
# dev.off()