data <- read.csv("data/metrics_elasticsearch.csv")

X <- log(data$linesChanged + 1)
Y <- as.integer(data$buggy == "true")

results <- NULL

for (seed in 0:100) {
  # Observed variable N and X.
  N <- length(X) # Number of commits (cf. original data set).
  X <- X # N random values (normal dist.).

  # Unobserved variable
  alpha <- -3.0
  beta <- 0.4
  prob <- 1 / (1 + exp(-(alpha + beta * X)))

  # Observed variable Y.
  Y <- rbinom(N, size = 1, prob = prob)

  model <- glm(Y ~ X, family = binomial())

  results <- rbind(results, coef(model))
}

pdf("generated/nutshell_uncertainty.pdf", width = 6, height = 3)
par(mfrow = c(1, 2), mar = c(2, 4, 2, 1))
hist(results[, 1], breaks = 20, main = "Inferred Intercepts (alpha)", xlab = "")
hist(results[, 2], breaks = 20, main = "Inferred Slopes (beta)", xlab = "")
dev.off()