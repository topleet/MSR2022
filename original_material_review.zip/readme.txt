This material contains the R scripts for running all simulations that are part of the paper. It produces ALL plots and models. Some non-standard libraries (for reproducing the original methodology of the related studies) may need to be installed before running some of the scripts. Each file includes dedicated imports.

We recommend exploring the simulation parameters and checking the effect on the results and plots.

By default, all plots are saved as pdf. Instructions ("pdf" and "dev.off") can be removed to directly show the plots in a window. The allows more interactive exploration.

The simulations are structured and named according to the sections in the paper.

We also added the two data sets that we used from the related work for review.